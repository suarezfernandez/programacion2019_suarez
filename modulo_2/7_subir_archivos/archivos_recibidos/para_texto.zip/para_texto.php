
<!-- Como contar la longitud de un texto -->

<?php
echo "<h4>1.Longitud de texto</h4> <br>";
$cadena = "Palabra";
echo strlen ($cadena);
echo "<br><br>";
?>

<!-- Convertir texto a array -->

<?php
echo "<h4>2.Convertir texto a array</h4>";
$cadena = "uno,dos,tres,cuatro,cinco";
$array = explode(",", $cadena);
echo "<br>El número de elementos en el array es: " . count($array);

echo "<pre>";
print_r($array);
echo "</pre>";
?>


<!-- Dividir un texto -->

<?php
echo "<h4>3.Dividiendo el texto</h4>";
$str = "Hello Friend";
echo "<br>" . "<h5>{$str}</h5>";
$arr1 = str_split($str);
$arr2 = str_split($str, 3);
 
echo "<pre>";
print_r($arr1);
print_r($arr2);
echo "</pre>";

?>


<!-- Convertir un texto a mayuscula -->

<?php
echo "<h4>4.Texto a mayuscula</h4>";
echo strtoupper("hola usuario"); //-->HOLA USUARIO --> todo a mayúsculas
?>


<!-- Convertir un texto a minuscula -->

<?php
echo "<h4>5.Texto a miniscula</h4>";
echo strtolower("hola USUARIO"); //--> hola usuario --> todo a minúsculas
?>